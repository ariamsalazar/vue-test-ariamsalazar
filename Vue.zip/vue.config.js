module.exports = {
    devServer: {
       headers: {
          'X-Frame-Options': 'sameorigin'
      }
    }
}