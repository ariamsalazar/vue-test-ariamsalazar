<!-- Header Template -->
<template>
    <div class="header">
       <div class="header__logo"></div>
       <div class="header__name"><b>By:</b> Ariam Salazar</div>
    </div>
</template>

<script>
export default {
  name: 'Header'
}
</script> 