<!-- Header Template -->
<template>
    <div class="footer">
        PicSum API - Test
    </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script> 